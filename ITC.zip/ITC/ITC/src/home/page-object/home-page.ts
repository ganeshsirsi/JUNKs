import { by, element, ElementFinder } from "protractor";

export class HomePage {

    public static SearchTextBoxy(): ElementFinder {
        return element(by.id('search_query_top'));
    }

    public static searchButton(): ElementFinder {
        return element(by.name("submit_search"));
    }
	
	public static searchGrid(): ElementFinder {
        return element(by.css(".product_list grid row"));
    }
	
	public static signInButton(): ElementFinder {
        return element(by.css(".login"));
    }
    public static emailText(): ElementFinder {
        return element(by.id('email_create'));
    }


    public static submitCreate(): ElementFinder {
        return element(by.id('SubmitCreate'));
    }
    public static error(): ElementFinder {
        return element(by.css('#create_account_error>ol'));
    }
    public static emailSignIn(): ElementFinder {
        return element(by.id('email'));
    }

    public static pwdSignIn(): ElementFinder {
        return element(by.id('passwd'));
    }
    public static SubmitLogin(): ElementFinder {
        return element(by.id('SubmitLogin'));
    }
    public static passwordError(): ElementFinder {
        return element(by.css('#center_column>div >ol'));
    }
	public static forgotPassword(): ElementFinder {
        return element(by.css('#login_form > div > p.lost_password.form-group>a'));
    }

    public static forgotPasswordSubmit(): ElementFinder {
        return element(by.css('form#form_forgotpassword button[type="submit"]'));
    }
    public static alertSuccess(): ElementFinder {
        return element(by.css('p[class="alert alert-success"]'));
    }

    public static alertFail(): ElementFinder {
        return element(by.css('#center_column > div > div>ol'));
    }
}