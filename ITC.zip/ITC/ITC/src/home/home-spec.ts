import {browser,element,by, ProtractorExpectedConditions} from 'protractor';
import {HomePage} from '../home/page-object/home-page'
describe('SignIn Page',()=> { 
	browser.manage().window().maximize();
	browser.waitForAngularEnabled(false);
	const until: ProtractorExpectedConditions = browser.ExpectedConditions;
		it('Verify Empty Email ID Register', () => { 
		browser.get('http://automationpractice.com') 
		.then(() =>HomePage.signInButton().click())
		.then(()=>browser.wait(until.visibilityOf(HomePage.submitCreate()),
		30000, ""))
		.then(()=>HomePage.submitCreate().click())
		.then(()=>browser.wait(until.visibilityOf(HomePage.error()),
		30000, ""))
		.then(()=>HomePage.error().getText())
		.then((text)=>expect(text).toContain('Invalid email address'));
	}); 

	it('Verify Existing Email ID', () => { 
		browser.get('http://automationpractice.com') 
		.then(() =>HomePage.signInButton().click())
		.then(() =>HomePage.emailText().sendKeys('test@test.com'))
		.then(()=>browser.wait(until.visibilityOf(HomePage.submitCreate()),
		30000, ""))
		.then(()=>HomePage.submitCreate().click())
		.then(()=>browser.wait(until.visibilityOf(HomePage.error()),
		30000, ""))
		.then(()=>HomePage.error().getText())
		.then((text)=>expect(text).toContain('An account using this email address has already been registered'));
	}); 

	it('Sign in Invalid Password', () => { 
		browser.get('http://automationpractice.com') 
		.then(() =>HomePage.signInButton().click())
		.then(() =>HomePage.emailSignIn().sendKeys('test@test.com'))
		.then(()=>browser.wait(until.visibilityOf(HomePage.SubmitLogin()),
		30000, ""))
		.then(() =>HomePage.pwdSignIn().sendKeys('test'))
		.then(() =>HomePage.SubmitLogin().click())
		.then(()=>browser.wait(until.visibilityOf(HomePage.passwordError()),
		30000, ""))
		.then(()=>HomePage.passwordError().getText())
		.then((text)=>expect(text).toContain('Invalid password'));
	}); 


	it('Verify Forgot Password Valid Email', () => { 
		browser.get('http://automationpractice.com') 
		.then(() =>HomePage.signInButton().click())
		.then(() =>HomePage.forgotPassword().click())
		.then(() =>HomePage.emailSignIn().sendKeys('test@test.com'))
		
		.then(()=>browser.wait(until.visibilityOf(HomePage.forgotPasswordSubmit()),
		30000, ""))
		.then(() =>HomePage.forgotPasswordSubmit().click())
		.then(()=>HomePage.alertSuccess().getText())
		.then((text)=>expect(text).toContain('A confirmation email has been sent'));
	}); 

	it('Verify Forgot Password Invalid Email', () => { 
		browser.get('http://automationpractice.com') 
		.then(() =>HomePage.signInButton().click())
		.then(() =>HomePage.forgotPassword().click())
		.then(() =>HomePage.emailSignIn().sendKeys('test@tes1t.com'))
		
		.then(()=>browser.wait(until.visibilityOf(HomePage.forgotPasswordSubmit()),
		30000, ""))
		.then(() =>HomePage.forgotPasswordSubmit().click())
		.then(()=>HomePage.alertFail().getText())
		.then((text)=>expect(text).toContain('There is no account registered for this email'));
	}); 


});
