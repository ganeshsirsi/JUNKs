/**
 * Author Ganesh Hegde  https://linkedin.com/in/ganeshsirsi/
 */



exports.config = {

    framework: 'jasmine', //Type of Framework used 
    directConnect:true,
    specs: ['./src/home/home-spec.ts'], //Name of the Specfile

    //Global Variable access this variable using browser.params.defaultBrowserTimeOut
    //You can add any number of variable inside params
    params: {
        defaultBrowserTimeOut: 30 * 1000
    },

    //Jasmine Options - Optional
    /*
    jasmineNodeOpts: {
            showColors: true,
            defaultTimeoutInterval: 3 * 60 * 1000,
            keepAlive: true,
            print: function () { }
        },
    /*
    //seleniumAddress: 'http://localhost:4444/wd/hub',

    // Configuring Test Suites
    /*suites: {
        home: ['./src/home-spec.ts'],
        search: ['./src/search-spec.ts,./src/search2-spec.ts'],
    }, 
    */

  //  Run Protractor Tests on Specific browser
    capabilities: {
        'browserName': 'chrome',
    },

   
    onPrepare() {
       // browser.waitForAngularEnabled(false);
        console.log( browser.params.specs);
        require('ts-node').register({
            project: require('path').join(__dirname, './tsconfig.json')
        });
    }
  
  }
 